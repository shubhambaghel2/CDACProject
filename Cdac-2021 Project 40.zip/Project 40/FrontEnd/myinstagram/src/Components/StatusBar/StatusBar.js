import { Avatar } from "@material-ui/core";
import React,{Component} from "react";
import  './StatusBar.css';
import statusimg from '../../images/Aang-And-Superman.webp';
import statusimg1 from '../../images/avatar1.jpg';
import statusimg2 from '../../images/avatar2.jpg';
import statusimg3 from '../../images/avatar3.jpg';
import statusimg4 from '../../images/avatar4.jpg';
import statusimg5 from '../../images/avatar5.png';
import statusimg6 from '../../images/avatar6.jfif';
import statusimg7 from '../../images/avatar7.jfif';
import uploadImage from "../../images/statusadd.png"
class StatusBar extends Component {
    constructor(props){
    super(props);
    this.state={ statusList:[]}
    }
    componentDidMount(){
        this.getData();
    }
    getData=()=> {
        let data=[
            {
                "username":"rishu",
                "imageUrl":statusimg
            },
            {
                "username":"vaibhav",
                "imageUrl":statusimg1
            },
            {
                "username":"varun",
                "imageUrl":statusimg2
            },
            {
                "username":"veer",
                "imageUrl":statusimg3
            },
            {
                "username":"ansi",
                "imageUrl":statusimg4
            },
            {
                "username":"rahul",
                "imageUrl":statusimg5
            },
            {
                "username":"aarti",
                "imageUrl":statusimg6
            },
            {
                "username":"nancy",
                "imageUrl":statusimg7
            }

        ]
        this.setState({statusList:data});
    }
    render(){
        return(
             <div className="statusbar_container">
                 <div>
                     <img src={uploadImage} className="statusbar_upload" width="55px" height="55px"/>
                 </div>
                {
                this.state.statusList.map((item,index)=>(
                    <div className="status">
                  <Avatar className="statusbar_status"src={item.imageUrl}/>
                  
                  <div className="statusbar_text">{item.username}</div>
                </div>
                ))
                }
               
            </div>  
        );
    }
}
    export default StatusBar;