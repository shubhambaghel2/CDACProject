import React,{Component} from "react";
import  './InfoSection.css';
import imageSrc from "../../images/pp4.jpeg"
import { Avatar } from "@material-ui/core";
class InfoSection extends Component {
    constructor(props){
    super(props);
    this.state={ }
    }
    render(){
        return(
            <div className="info_container">
              <Avatar src={imageSrc} className="info_image"/>
              <div className="info_content">
              <div className="info_username">Rishu_Singh</div>
              <div className="info_description">description</div>
              </div>
            </div>  
        );
    }
}
    export default InfoSection;