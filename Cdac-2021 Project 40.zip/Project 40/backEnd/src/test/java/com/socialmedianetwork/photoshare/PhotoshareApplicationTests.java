package com.socialmedianetwork.photoshare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoshareApplicationTests {

	@Test
	void contextLoads() {
	}

}
