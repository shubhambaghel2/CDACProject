package com.socialmedianetwork.photoshare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotoshareApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhotoshareApplication.class, args);
	}

}
